import React, { createContext, useContext, useMemo, useState } from "react";

const FilterContext = createContext(null);

export function FilterProvider({ children }) {
  const [name, setName] = useState("");
  const [priceSort, setPriceSort] = useState("");

  const value = useMemo(
    () => ({ name, setName, priceSort, setPriceSort }),
    [name, priceSort]
  );

  return <FilterContext.Provider value={value}>{children}</FilterContext.Provider>;
}

export function useFilter() {
  const ctx = useContext(FilterContext);
  if (!ctx) throw new Error("useFilter must be used inside FilterProvider");
  return ctx;
}
