import React, { useState } from "react";
import { useCart } from "../contexts/CartContext";

export default function Cart() {
  const { cartItems, removeFromCart, setQty, createOrder } = useCart();
  const [msg, setMsg] = useState("");
  const [err, setErr] = useState("");

  async function onCreate() {
    setMsg("");
    setErr("");
    try {
      const order = await createOrder();
      setMsg(`Order created: ${order.id}`);
    } catch (e) {
      setErr(String(e.message || e));
    }
  }

  return (
    <div style={{ padding: 12 }}>
      <h2>Cart</h2>
      {err && <p style={{ color: "red" }}>{err}</p>}
      {msg && <p>{msg}</p>}

      {cartItems.length === 0 ? (
        <p>Cart is empty</p>
      ) : (
        <ul style={{ display: "grid", gap: 8, paddingLeft: 16 }}>
          {cartItems.map((it) => (
            <li key={it.Id}>
              {it.Name} — Qty:{" "}
              <input
                type="number"
                min="1"
                value={it.Qty}
                onChange={(e) => setQty(it.Id, e.target.value)}
                style={{ width: 60 }}
              />{" "}
              <button onClick={() => removeFromCart(it.Id)}>Remove</button>
            </li>
          ))}
        </ul>
      )}

      <div style={{ marginTop: 12 }}>
        <button onClick={onCreate} disabled={cartItems.length === 0}>
          Create order
        </button>
      </div>
    </div>
  );
}
