import React, { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { getProductById } from "../api";
import { useCart } from "../contexts/CartContext";

export default function Product() {
  const { id } = useParams();
  const { addToCart } = useCart();

  const [product, setProduct] = useState(null);
  const [err, setErr] = useState("");

  useEffect(() => {
    let alive = true;
    setErr("");
    setProduct(null);

    getProductById(id)
      .then((p) => alive && setProduct(p))
      .catch((e) => alive && setErr(String(e.message || e)));

    return () => {
      alive = false;
    };
  }, [id]);

  if (err) {
    return (
      <div style={{ padding: 16 }}>
        <p style={{ color: "red" }}>{err}</p>
        <Link to="/">← Back to products</Link>
      </div>
    );
  }

  if (!product) return <div style={{ padding: 16 }}>Loading...</div>;

  return (
    <div style={{ padding: 16 }}>
      <Link to="/">← Back to products</Link>

      <div
        style={{
          marginTop: 12,
          maxWidth: 720,
          border: "1px solid #ddd",
          borderRadius: 12,
          padding: 16
        }}
      >
        <h2 style={{ marginTop: 0 }}>{product.Name}</h2>

        <p style={{ marginTop: 8 }}>
          <b>Description:</b><br />
          {product.Description || "No description"}
        </p>

        <div style={{ display: "grid", gap: 6, marginTop: 10 }}>
          <div><b>Id:</b> {product.Id}</div>
          <div><b>Price:</b> {product.Price}</div>
          <div><b>Qty:</b> {product.Qty}</div>
        </div>

        <div style={{ marginTop: 12 }}>
          <button onClick={() => addToCart(product)} disabled={Number(product.Qty) <= 0}>
            Add to cart
          </button>
          {Number(product.Qty) <= 0 && (
            <span style={{ marginLeft: 10, color: "#b00" }}>Out of stock</span>
          )}
        </div>
      </div>
    </div>
  );
}
