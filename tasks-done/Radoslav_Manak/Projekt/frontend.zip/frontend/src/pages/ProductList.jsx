import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { getProducts } from "../api";
import { useFilter } from "../contexts/FilterContext";
import { useCart } from "../contexts/CartContext";

export default function ProductList() {
  const { name, priceSort } = useFilter();
  const { addToCart } = useCart();

  const [products, setProducts] = useState([]);
  const [err, setErr] = useState("");

  useEffect(() => {
    let alive = true;
    setErr("");
    getProducts({ name, price_sort: priceSort })
      .then((data) => alive && setProducts(data))
      .catch((e) => alive && setErr(String(e.message || e)));
    return () => {
      alive = false;
    };
  }, [name, priceSort]);

  return (
    <div style={{ padding: 12 }}>
      <h2>Products</h2>
      {err && <p style={{ color: "red" }}>{err}</p>}

      <ul style={{ display: "grid", gap: 8, paddingLeft: 16 }}>
        {products.map((p) => (
          <li key={p.Id}>
            <Link to={`/product/${p.Id}`}>{p.Name}</Link>
            {" — "}Price: {p.Price} {" — "}Qty: {p.Qty}{" "}
            <button onClick={() => addToCart(p)} disabled={Number(p.Qty) <= 0}>
              Add
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}
