const express = require("express");
const cors = require("cors");
const crypto = require("crypto");

const { LowSync } = require("lowdb");
const { JSONFileSync } = require("lowdb/node");

const app = express();
app.use(cors());
app.use(express.json());

const adapter = new JSONFileSync("db.json");
const db = new LowSync(adapter, { products: [], orders: [] });
db.read();
db.data ||= { products: [], orders: [] };

// GET /products?price_sort=asc|desc&name=string
app.get("/products", (req, res) => {
// GET /products/:id  (single product)
app.get("/products/:id", (req, res) => {
  db.read();
  const { id } = req.params;

  const product = (db.data.products || []).find((p) => String(p.Id) === String(id));
  if (!product) return res.status(404).json({ error: "Product not found" });

  res.setHeader("Content-Type", "application/json");
  res.send(JSON.stringify(product, null, 2));
});
  
  db.read();
  let products = [...(db.data.products || [])];

  const { price_sort, name } = req.query;

  if (typeof name === "string" && name.trim()) {
    const q = name.trim().toLowerCase();
    products = products.filter((p) =>
      String(p.Name ?? "").toLowerCase().includes(q)
    );
  }

  if (price_sort === "asc" || price_sort === "desc") {
    const dir = price_sort === "asc" ? 1 : -1;
    products.sort((a, b) => (Number(a.Price) - Number(b.Price)) * dir);
  }

  res.setHeader("Content-Type", "application/json");
  res.send(JSON.stringify(products, null, 2));

});

// GET /orders
app.get("/orders", (req, res) => {
  db.read();
  res.json(db.data.orders || []);
});

// POST /orders  body: [{Id, Qty}]
app.post("/orders", (req, res) => {
  db.read();

  const products = req.body;
  if (!Array.isArray(products)) {
    return res.status(400).json({ error: "Body must be an array" });
  }

  const dbProducts = db.data.products || [];
  const dbOrders = db.data.orders || [];

  const id = crypto.randomUUID();

  for (const product of products) {
    const i = dbProducts.findIndex((pr) => pr.Id === product.Id);
    if (i === -1) return res.status(400).json({ error: "Product not found: " + product.Id });

    const dec = Number(product.Qty);
    if (!Number.isFinite(dec) || dec <= 0) return res.status(400).json({ error: "Bad Qty for: " + product.Id });
    if (Number(dbProducts[i].Qty) < dec) return res.status(400).json({ error: "Not enough stock for: " + product.Id });

    dbProducts[i].Qty = Number(dbProducts[i].Qty) - dec;
  }

  const order = {
    id,
    date: new Date().toISOString(),
    products: products.map((p) => ({ id: p.Id, qty: Number(p.Qty) })),
  };

  dbOrders.push(order);
  db.data.products = dbProducts;
  db.data.orders = dbOrders;
  db.write();

  res.json(order);
});

app.listen(3001, () => console.log("Backend: http://localhost:3001"));
