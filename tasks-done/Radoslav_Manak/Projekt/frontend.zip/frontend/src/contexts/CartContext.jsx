import React, { createContext, useContext, useMemo, useState } from "react";
import { postOrder } from "../api";

const CartContext = createContext(null);

export function CartProvider({ children }) {
  const [cartItems, setCartItems] = useState([]);

  function addToCart(product) {
    setCartItems((prev) => {
      const i = prev.findIndex((x) => x.Id === product.Id);
      if (i >= 0) {
        const copy = [...prev];
        copy[i] = { ...copy[i], Qty: Number(copy[i].Qty) + 1 };
        return copy;
      }
      return [...prev, { ...product, Qty: 1 }];
    });
  }

  function removeFromCart(id) {
    setCartItems((prev) => prev.filter((x) => x.Id !== id));
  }

  function setQty(id, qty) {
    setCartItems((prev) =>
      prev.map((x) => (x.Id === id ? { ...x, Qty: Number(qty) } : x))
    );
  }

  function clearCart() {
    setCartItems([]);
  }

  async function createOrder() {
    const order = await postOrder(cartItems);
    clearCart();
    return order;
  }

  const value = useMemo(
    () => ({ cartItems, addToCart, removeFromCart, setQty, clearCart, createOrder }),
    [cartItems]
  );

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart must be used inside CartProvider");
  return ctx;
}
