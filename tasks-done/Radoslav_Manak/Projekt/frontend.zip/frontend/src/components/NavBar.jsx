import React from "react";
import { Link } from "react-router-dom";
import { useFilter } from "../contexts/FilterContext";

export default function NavBar() {
  const { name, setName, priceSort, setPriceSort } = useFilter();

  return (
    <div style={{ borderBottom: "1px solid #ddd", padding: 12 }}>
      <nav style={{ display: "flex", gap: 12 }}>
        <Link to="/">Products</Link>
        <Link to="/orders">Orders</Link>
        <Link to="/cart">Cart</Link>
      </nav>

      <div style={{ marginTop: 12, display: "flex", gap: 8, alignItems: "center" }}>
        <input
          type="text"
          placeholder="Search by name..."
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <button onClick={() => setPriceSort("asc")} disabled={priceSort === "asc"}>
          Price ↑
        </button>
        <button onClick={() => setPriceSort("desc")} disabled={priceSort === "desc"}>
          Price ↓
        </button>
        <button onClick={() => { setName(""); setPriceSort(""); }}>
          Reset
        </button>
      </div>
    </div>
  );
}
