import React, { useEffect, useState } from "react";
import { getOrders } from "../api";

export default function Orders() {
  const [orders, setOrders] = useState([]);
  const [err, setErr] = useState("");

  useEffect(() => {
    let alive = true;
    setErr("");
    getOrders()
      .then((data) => alive && setOrders(data))
      .catch((e) => alive && setErr(String(e.message || e)));
    return () => {
      alive = false;
    };
  }, []);

  return (
    <div style={{ padding: 12 }}>
      <h2>Orders</h2>
      {err && <p style={{ color: "red" }}>{err}</p>}

      {orders.length === 0 ? (
        <p>No orders</p>
      ) : (
        <ul style={{ display: "grid", gap: 12, paddingLeft: 16 }}>
          {orders.map((o) => (
            <li key={o.id} style={{ border: "1px solid #ddd", padding: 8 }}>
              <div><b>Id:</b> {o.id}</div>
              <div><b>Date:</b> {o.date}</div>
              <div><b>Products:</b></div>
              <ul>
                {o.products?.map((p, idx) => (
                  <li key={idx}>productId: {p.id}, qty: {p.qty}</li>
                ))}
              </ul>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
