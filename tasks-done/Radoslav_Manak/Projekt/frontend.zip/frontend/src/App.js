import React from "react";
import { Routes, Route } from "react-router-dom";
import NavBar from "./components/NavBar";
import ProductList from "./pages/ProductList";
import Product from "./pages/Product";
import Orders from "./pages/Orders";
import Cart from "./pages/Cart";

export default function App() {
  return (
    <div>
      <NavBar />
      <Routes>
        <Route path="/" element={<ProductList />} />
        <Route path="/product/:id" element={<Product />} />
        <Route path="/orders" element={<Orders />} />
        <Route path="/cart" element={<Cart />} />
      </Routes>
    </div>
  );
}
