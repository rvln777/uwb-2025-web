export async function getProducts({ name = "", price_sort = "" } = {}) {
  const params = new URLSearchParams();
  if (name) params.set("name", name);
  if (price_sort) params.set("price_sort", price_sort);

  const res = await fetch(`/products?${params.toString()}`);
  if (!res.ok) throw new Error("Failed to load products");
  return res.json();
}

export async function getOrders() {
  const res = await fetch(`/orders`);
  if (!res.ok) throw new Error("Failed to load orders");
  return res.json();
}

export async function postOrder(cartItems) {
  const body = cartItems.map((it) => ({ Id: it.Id, Qty: it.Qty }));

  const res = await fetch(`/orders`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });

  if (!res.ok) throw new Error(await res.text());
  return res.json();
}
export async function getProductById(id) {
  const res = await fetch(`/products/${id}`);
  if (!res.ok) throw new Error("Failed to load product");
  return res.json();
}
